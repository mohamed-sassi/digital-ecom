<template>
    <div >
        
         <v-btn block color="#3b7bbf"  >PayPal</v-btn>
         <v-row>
             <v-col cols="2"></v-col>
         <button>   
         <v-img  width="48px" src="https://img.icons8.com/color/48/000000/visa.png"  ></v-img> 
         </button>
         <button>
         <v-img width="48px" src="https://img.icons8.com/color/48/000000/mastercard.png"></v-img>
         </button>
        <button>
        <v-img width="48px" src="https://img.icons8.com/wired/64/000000/google-pay.png"></v-img>
        </button>
        </v-row>
    </div>
</template>
<script>
export default {
    
}
</script>
